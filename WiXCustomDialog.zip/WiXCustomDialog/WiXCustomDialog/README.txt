Sample of a custom dialog with a custom image.

The "WixUI_Mondo.wxs" file is the original WiX GUI template. 

The "WixUI_MyMondo.wxs" file is a modified WiX GUI template.

 - Adding an embedded dialog called "ServerDlg"
 - Redirecting some buttons to insert the new dialog into the dialog sequence.
 - That redirecting entails pointing some next and back buttons to a different dialog.
